# this is where you would include the other src files so that the users would have acces to the functions that you want then to
module AirBorne
# Write your package code here.

include("Data.jl")
include("Plotting.jl")
include("Simple.jl")
include("Errors.jl")
include("Behavioural.jl")
include("Buy_sell.jl")


end
